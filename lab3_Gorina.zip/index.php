<?php
function write_tofile($data) {
    $file = 'databases.txt';
    if (!file_exists($file)) {
        touch($file);
        chmod($file, 0666);
    }

    $pp_number = isset($data['prm000']) ? $data['prm000'] : 'N/A';
    unset($data['prm000']);

    if (isset($data['prm6']) && isset($data['prm100'])) {
        $data['prm6'] = $data['prm6'] . ' — ' . $data['prm100'];
        unset($data['prm100']);
    }

    $newData = $pp_number . " | " . implode(" | ", $data) . "\n";

    if (checking_rec($file, $pp_number)) {
        overwrite($file, $pp_number, $newData);
    } else {
        if (file_put_contents($file, $newData, FILE_APPEND) === false) {
            die("ошибка записи");
        }
    }
}

function checking_rec($file, $pp_number) {
    if (file_exists($file)) {
        $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $data = explode(" | ", $line);
            if ($data[0] === $pp_number) {
                return true;
            }
        }
    }
    return false;
}

function overwrite($file, $pp_number, $newData) {
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $newLines = [];
    foreach ($lines as $line) {
        $data = explode(" | ", $line);
        if ($data[0] === $pp_number) {
            $newLines[] = $newData;
        } else {
            $newLines[] = $line;
        }
    }
    file_put_contents($file, implode("\n", $newLines) . "\n");
}

function read_tofile() {
    $file = 'databases.txt';
    if (file_exists($file)) {
        $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!empty($lines)) {
            echo "<table border='1'>";
            echo "<tr><th>Номер записи</th><th>Год выпуска игры</th><th>Жанры</th><th>Платформа</th><th>Режим игры</th><th>Рейтинг более</th><th>Язык</th><th>Ваши предложения по расширению параметров поиска?</th></tr>";
            foreach ($lines as $line) {
                $data = explode(" | ", $line);
                $pp_number = $data[0];
                $prm1 = $data[1];
                $prm2 = $data[2];
                $prm3 = $data[3];
                $prm4 = $data[4];
                $prm5 = $data[5];
                $prm6 = $data[6];
                $prm7 = $data[7];
                $prm8 = $data[8];
                $prm9 = $data[9];
                $prm10 = $data[10];
                $prm11 = $data[11];
                $prm12 = $data[12];
                $prm13 = $data[13];
                $prm14 = $data[14];
                $prm15 = $data[15];
                $prm16 = $data[16];
                $prm17 = $data[17];

                // логика для года выпуска игры
                $year = [];
                if ($prm1 == '0') {
                    $year[] = "Старые игры, до $prm2 года выпуска";
                }
                if ($prm3 == '0') {
                    $year[] = "Новые игры, после $prm4 года выпуска";
                }
                if ($prm5 == '0') {
                    $year[] = "Игры во временном промежутке: $prm6";
                }
                $year = !empty($year) ? implode(", ", $year) : "Не указан";

                // логика для жанра
                if (!empty($prm7)) {
                    $genres = $prm7;
                } elseif (!empty($prm8)) {
                    $genres = "Другой: $prm8";
                } else {
                    $genres = "Не указан";
                }

                // логика для платформы
                $platform = [];
                if ($prm9 == 'Да') {
                    $platform[] = "PC";
                }
                if ($prm10 == 'Да') {
                    $platform[] = "Xbox";
                }
                if ($prm11 == 'Да') {
                    $platform[] = "PS";
                }
                $platform = !empty($platform) ? implode(", ", $platform) : "Не указана";

                // логика для режима игры
                $regim = [];
                if ($prm12 == 'Да') {
                    $regim[] = "мультиплеер";
                }
                if ($prm13 == 'Да') {
                    $regim[] = "одиночная";
                }
                $regim = !empty($regim) ? implode(", ", $regim) : "Не указан";

                // логика для выбора языка
                $lern = [];
                if ($prm15 == 'Да') {
                    $lern[] = "на русском языке";
                }
                if ($prm16 == 'Да') {
                    $lern[] = "с русской озвучкой";
                }
                $lern = !empty($lern) ? implode(", ", $lern) : "Не указан";

                echo "<tr>";
                echo "<td>$pp_number</td>";
                echo "<td>$year</td>";
                echo "<td>$genres</td>";
                echo "<td>$platform</td>";
                echo "<td>$regim</td>";
                echo "<td>$prm14</td>";
                echo "<td>$lern</td>";
                echo "<td>$prm17</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "данных нет";
        }
    } else {
        echo "файл не существует";
    }
}

$file = 'databases.txt';
if (!file_exists($file)) {
    touch($file);
    chmod($file, 0666);
}

function typedate_no($data) {
    if (!isset($data['dataField'])) {
        $data['radioField1'] = isset($_POST['radioField1']) ? $_POST['radioField1'] : '';
        $data['radioField2'] = isset($_POST['radioField2']) ? $_POST['radioField2'] : '';
    }
    return $data;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'prm000' => isset($_POST['prm000']) ? $_POST['prm000'] : '',
        'prm1' => isset($_POST['prm1']) ? $_POST['prm1'] : '',
        'prm2' => isset($_POST['prm2']) ? $_POST['prm2'] : '',
        'prm3' => isset($_POST['prm3']) ? $_POST['prm3'] : '',
        'prm4' => isset($_POST['prm4']) ? $_POST['prm4'] : '',
        'prm5' => isset($_POST['prm5']) ? $_POST['prm5'] : '',
        'prm6' => isset($_POST['prm6']) ? $_POST['prm6'] : '',
        'prm100' => isset($_POST['prm100']) ? $_POST['prm100'] : '',
        'prm7' => isset($_POST['prm7']) ? $_POST['prm7'] : '',
        'prm8' => isset($_POST['prm8']) ? $_POST['prm8'] : '',
        'prm9' => isset($_POST['prm9']) ? 'Да' : '',
        'prm10' => isset($_POST['prm10']) ? 'Да' : '',
        'prm11' => isset($_POST['prm11']) ? 'Да' : '',
        'prm12' => isset($_POST['prm12']) ? 'Да' : '',
        'prm13' => isset($_POST['prm13']) ? 'Да' : '',
        'prm14' => isset($_POST['prm14']) ? $_POST['prm14'] : '',
        'prm15' => isset($_POST['prm15']) ? 'Да' : '',
        'prm16' => isset($_POST['prm16']) ? 'Да' : '',
        'prm17' => isset($_POST['prm17']) ? $_POST['prm17'] : ''
    ];

    $data = typedate_no($data);
    write_tofile($data);

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<div style="display: flex; flex-direction: column; align-items: center;">
    <form action="index.php" method="post">
    <div class="textstyle1">
        <table>
            <thead>
            <tr>
                <th colspan="3">Поиск игры</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td colspan="3">Онлайн-советчик «Маруся» подберёт наиболее подходящую игру!</td>
            </tr>
            <tr>
                <td colspan="3">
                    <label for="pp_number">Номер записи:</label>
                    <input type="text" id="pp_number" name="prm000" required>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <p><input type="radio" id="radio1" name="prm1" value="0" class="prm1_1">
                        <label for="radio1">Старые игры, до <input type="number" value="0" title="" name="prm2" class="prm1_1">
                            года выпуска</p></label>
                    <p><input type="radio" id="radio2" name="prm3" value="0" class="prm2_1">
                        <label for="radio2">Новые игры, после
                            <input type="number" value="0" title="" name="prm4" class="prm2_1">
                            года выпуска</p></label>
                    <p><input type="radio" id="radio3" name="prm5" value="0" class="prm3_1">
                        <label for="radio3">Игры во временном промежутке:
                            <input type="date" name="prm6" class="prmcss10"> — <input type="date" name="prm100" class="prm3_1"></p></label>
                </td>
                <td>
                    Жанры:<br/>
                    <br/>
                    <select name="prm7" size="5" class="prm4_1">
                        <option value="kvest">Квест</option>
                        <option value="rpg">РПГ</option>
                        <option value="sport">Спорт</option>
                        <option value="strategy">Стратегия</option>
                        <option value="shuter">Шутер</option>
                    </select><br/>
                    <br/><p>другой: <input type="number" id="number" name="prm8" value="" class="prm5_1"></p>
                </td>
            </tr>
            <tr>
                <td>
                    <p>Платформа: <input type="radio" id="radio1" name="prm9" class="prm6_1">
                        PC&nbsp;<input type="radio" id="radio2" name="prm10" class="prm6_1">
                        Xbox&nbsp;<input type="radio" id="radio3" name="prm11" class="prm6_1">
                        PS</p>
                </td>
                <td>
                    <p style="text-align: right;">Режим игры:</p>
                </td>
                <td>
                    <input type="checkbox" id="chb1" name="prm12" class="prm7_1">
                    мультиплеер<br/>
                    <input type="checkbox" id="chb2" name="prm13" class="prm7_1">одиночная
                </td>
            </tr>
            <tr>
                <td colspan="3">Рейтинг более:<br/>
                    <span class="prm8_1">1 звезда</span><input type="range" id="range1" name="prm14" min="1" max="10" class="prm7_1">
                    <span class="prm8_1">10 звёзд</span>
                </td>
            </tr>
            <tr>
                <td rowspan="2">&nbsp;</td>
                <td>
                    <input type="checkbox" id="chb1" name="prm15" class="prm7_1">
                    на русском языке<br/>
                    <input type="checkbox" id="chb2" name="prm16" class="prm7_1">с русской озвучкой
                </td>
                <td rowspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td class="prm9">
                    Ваши предложения по расширению параметров поиска?
                    <br/>
                    <br/><textarea name="prm17" class="prm9_1" rows="4" cols="20"></textarea>
                </td>
            </tr>
            <tr>
                <td colspan="3" class="prm9">
                    <button type="submit">Искать</button>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
</form>
<p>&nbsp;</p>

<?php
read_tofile();
?>
</div>
</body>
</html>