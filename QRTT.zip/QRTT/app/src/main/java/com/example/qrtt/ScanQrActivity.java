package com.example.qrtt;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.journeyapps.barcodescanner.CaptureManager;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class ScanQrActivity extends AppCompatActivity {

    private static final String TAG = "ScanQrActivity";
    private static final int REQUEST_CODE = 123; // Вы можете выбрать любое значение

    private CaptureManager capture;
    private DecoratedBarcodeView barcodeView;

    private DatabaseReference databaseReference;
    private DatabaseReference qrCodesReference;

    private boolean isEntry = true; // Флаг для определения входа или выхода

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_qr);

        barcodeView = findViewById(R.id.barcode_scanner);
        capture = new CaptureManager(this, barcodeView);
        capture.initializeFromIntent(getIntent(), savedInstanceState);
        capture.decode();

        // Инициализация Firebase Realtime Database
        databaseReference = FirebaseDatabase.getInstance().getReference("scans");
        qrCodesReference = FirebaseDatabase.getInstance().getReference("qr_codes");
    }

    @Override
    protected void onResume() {
        super.onResume();
        capture.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        capture.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        capture.onDestroy();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        capture.onSaveInstanceState(outState);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                String scannedData = data.getStringExtra("SCAN_RESULT");
                Log.d(TAG, "onActivityResult: Scanned data received: " + scannedData);
                handleScannedData(scannedData);
            } else {
                Log.d(TAG, "onActivityResult: Scanning failed or cancelled");
                setResult(RESULT_CANCELED);
                finish();
            }
        }
    }

    // Метод для обработки результата сканирования
    public void handleScannedData(String scannedData) {
        Log.d(TAG, "handleScannedData called with scannedData: " + scannedData);

        qrCodesReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean isValidQrCode = false;
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String qrCode = snapshot.getValue(String.class);
                    if (scannedData.equals(qrCode)) {
                        isValidQrCode = true;
                        break;
                    }
                }

                if (isValidQrCode) {
                    FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                    if (currentUser != null) {
                        String userId = currentUser.getUid();
                        String userEmail = currentUser.getEmail();

                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                            LocalDateTime now = LocalDateTime.now();

                            databaseReference.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    String scanKey = null;
                                    if (dataSnapshot.exists()) {
                                        // Ищем последнее сканирование, где нет времени выхода
                                        for (DataSnapshot scanSnapshot : dataSnapshot.getChildren()) {
                                            if (!scanSnapshot.hasChild("release_time")) {
                                                scanKey = scanSnapshot.getKey();
                                                break;
                                            }
                                        }
                                    }

                                    if (scanKey != null) {
                                        // Если найдено последнее сканирование без времени выхода, обновляем его
                                        String entryTimeStr = dataSnapshot.child(scanKey).child("entry_time").getValue(String.class);
                                        LocalDateTime entryTime = LocalDateTime.parse(entryTimeStr, formatter);
                                        long timeDifference = ChronoUnit.HOURS.between(entryTime, now);

                                        databaseReference.child(userId).child(scanKey).child("release_time").setValue(now.format(formatter));
                                        databaseReference.child(userId).child(scanKey).child("time_hoursDifference").setValue(timeDifference)
                                                .addOnSuccessListener(aVoid -> {
                                                    Log.d(TAG, "Data updated in Firebase successfully");
                                                    Toast.makeText(ScanQrActivity.this, "Data updated in Firebase", Toast.LENGTH_SHORT).show();
                                                    Intent resultIntent = new Intent();
                                                    resultIntent.putExtra("SCAN_RESULT", scannedData);
                                                    setResult(RESULT_OK, resultIntent);
                                                    finish(); // Закрываем активность после обновления данных
                                                })
                                                .addOnFailureListener(e -> {
                                                    Log.e(TAG, "Failed to update data in Firebase", e);
                                                    Toast.makeText(ScanQrActivity.this, "Failed to update data in Firebase", Toast.LENGTH_SHORT).show();
                                                    setResult(RESULT_CANCELED);
                                                    finish();
                                                });
                                    } else {
                                        // Если не найдено последнее сканирование без времени выхода, создаем новое
                                        scanKey = databaseReference.child(userId).push().getKey();
                                        UserScan userScan = new UserScan(userId, now.format(formatter), null, 0, userEmail);

                                        databaseReference.child(userId).child(scanKey).setValue(userScan)
                                                .addOnSuccessListener(aVoid -> {
                                                    Log.d(TAG, "Data saved to Firebase successfully");
                                                    Toast.makeText(ScanQrActivity.this, "Data saved to Firebase", Toast.LENGTH_SHORT).show();
                                                    Intent resultIntent = new Intent();
                                                    resultIntent.putExtra("SCAN_RESULT", scannedData);
                                                    setResult(RESULT_OK, resultIntent);
                                                    finish(); // Закрываем активность после сохранения данных
                                                })
                                                .addOnFailureListener(e -> {
                                                    Log.e(TAG, "Failed to save data to Firebase", e);
                                                    Toast.makeText(ScanQrActivity.this, "Failed to save data to Firebase", Toast.LENGTH_SHORT).show();
                                                    setResult(RESULT_CANCELED);
                                                    finish();
                                                });
                                    }
                                    // Инвертируем флаг для следующего сканирования
                                    isEntry = !isEntry;
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                    Log.e(TAG, "Database error: " + databaseError.getMessage());
                                    setResult(RESULT_CANCELED);
                                    finish();
                                }
                            });
                        }
                    } else {
                        Log.d(TAG, "Invalid QR code");
                        Toast.makeText(ScanQrActivity.this, "Invalid QR code", Toast.LENGTH_SHORT).show();
                        setResult(RESULT_CANCELED);
                        finish();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "Database error: " + databaseError.getMessage());
                setResult(RESULT_CANCELED);
                finish();
            }
        });
    }
}